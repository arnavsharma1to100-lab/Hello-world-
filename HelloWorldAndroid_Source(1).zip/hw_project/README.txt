Hello World Android starter project
This is a front-end demo packaged in a simple Android WebView app. It is NOT a production messaging service. There is no backend, real OTP, cross-device chat, server media storage, or real voice/video calling.
Build using Gradle 8.9 and Android Gradle Plugin 8.7.3 with Java 17. Run: gradle assembleDebug. APK output: app/build/outputs/apk/debug/app-debug.apk
